/*
PLEASE DO NOT CHANGE THIS FILE 
*/

/* @Author
Student Name: <Muhammet Derviş Kopuz>
Student ID : <504201531>
Date: <10.11.2020> */

#define TOKEN_LENGTH 2

struct Token{
	char token[TOKEN_LENGTH];	
	int count=0;
};
