/*
PLEASE DO NOT CHANGE THIS FILE 
*/
#define TOKEN_LENGTH 2

struct Token{
	char token[TOKEN_LENGTH];	
	int count=0;
};
